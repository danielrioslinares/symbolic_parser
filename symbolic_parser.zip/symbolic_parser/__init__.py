
from sympy import *
import re

def mathcad_prime_7( txt ):
	# Parse the variables (@SUB identification)
	sub = [ m.start()-1 for m in re.finditer('(?=@SUB)', txt) if txt[m.start()-1] == "("]
	for sub_i in reversed(sub):
		sub_j = txt[sub_i:].find( ")" ) + sub_i
		sub_lbl = txt[sub_i+6:sub_j]
		txt = txt[:sub_i-1] + "_{}".format(sub_lbl) + txt[sub_j+1:]

	# Parse the variables (@ID identification)
	id = [ m.start()-1 for m in re.finditer('(?=@ID)', txt) if txt[m.start()-1] == "("]
	for id_i in reversed(id):
		id_j = txt[id_i:].find( ")" ) + id_i
		txt = txt[:id_i] + txt[id_i+5:id_j] + txt[id_j+1:]

	# Parse functions (@LABEL FUNCTION)
	fnc = [ m.start()-1 for m in re.finditer('(?=@LABEL FUNCTION)', txt) if txt[m.start()-1] == "("]
	for fnc_i in reversed(fnc):
		fnc_j = txt[fnc_i:].find( ")" ) + fnc_i
		txt = txt[:fnc_i] + txt[fnc_i+17:fnc_j] + txt[fnc_j+1:]

	# Parse variable (@LABEL VARIABLE)
	var = [ m.start()-1 for m in re.finditer('(?=@LABEL VARIABLE)', txt) if txt[m.start()-1] == "("]
	for var_i in reversed(var):
		var_j = txt[var_i:].find( ")" ) + var_i
		txt = txt[:var_i] + txt[var_i+17:var_j] + txt[var_j+1:]

	# Parse variable (@PARENS)
	par = [ m.start()-1 for m in re.finditer('(?=@PARENS)', txt) if txt[m.start()-1] == "("]
	for par_i in reversed(par):
		open = 0
		for par_j2 in range(par_i+9, len(txt)):
			if txt[par_j2] == "(":
				open += 1
			elif txt[par_j2] == ")":
				open -= 1
				if open == 0:
					par_j = par_j2
					break
		txt = txt[:par_i] + txt[par_i+9:par_j] + txt[par_j+1:]

	# Parse variable (@LABEL CONSTANT) https://docs.scipy.org/doc/scipy/reference/constants.html
	con = [ m.start()-1 for m in re.finditer('(?=@LABEL CONSTANT)', txt) if txt[m.start()-1] == "("]
	for con_i in reversed(con):
		con_j = txt[con_i:].find( ")" ) + con_i
		constant = txt[con_i+17:con_j]
		txt = txt[:con_i] + constant + txt[con_j+1:]

	# Create sub expressions
	u = "x" * ( len(txt) + 1 )
	v = {}
	k = 0
	while txt.count("(") > 1:
		# Get the parenthesis
		i0 = []
		d = {}
		for i,c in enumerate(txt):
			if c == '(':
				i0.append(i)
			elif c == ')':
				d[i0.pop()] = i+1
		# Create symbols
		uk = u + str(k)
		i,j = sorted(d.items())[-1]
		v[uk] = txt[i:j]
		txt = txt[:i] + uk + txt[j:]
		# Next
		k += 1

	# Operations
	fields = txt[1:-1].split()
	if fields[0] == "+":
		expr = Symbol( fields[1] ) + Symbol( fields[2] )
	elif fields[0] == "-":
		expr = Symbol( fields[1] ) - Symbol( fields[2] )
	elif fields[0] == "*":
		expr = Symbol( fields[1] ) * Symbol( fields[2] )
	elif fields[0] == "^":
		expr = Symbol( fields[1] ) ** Symbol( fields[2] )
	elif fields[0] == "/":
		expr = Symbol( fields[1] ) / Symbol( fields[2] )
	elif fields[0][:6] == "@SCALE":
		expr = Symbol( fields[1] ) * Symbol( fields[2] )
	elif fields[0] == "@NTHROOT":
		if fields[1] == "@PLACEHOLDER":
			expr = sqrt( Symbol( fields[2] ) )
		else:
			expr = Symbol( fields[2] )**( 1 / Symbol( fields[1] ) )
	elif fields[0][:6] == "@APPLY":
		if fields[1] == "sin":
			expr = sin( Symbol( fields[2] ) )
		elif fields[1] == "cos":
			expr = cos( Symbol( fields[2] ) )
		elif fields[1] == "tan":
			expr = tan( Symbol( fields[2] ) )
		elif fields[1] == "ln":
			expr = ln( Symbol( fields[2] ) )
		elif fields[1] == "log":
			expr = log( Symbol( fields[2] ) )
	elif fields[0][:5] == "@ARGS":
		expr = Symbol( fields[1] )
	elif fields[0][:4] == "@NEG":
		expr = - Symbol( fields[1] )

	# Expression generation
	while sum([ Symbol(k) in expr.free_symbols for k in v ]):
		for key,val in v.items():
			expr_key = mathcad_prime_7(val)
			expr = expr.subs( Symbol(key), expr_key )

	# Remove floats from symbols
	for sym in expr.free_symbols:
		try:
			num = float(str(sym))
			expr = expr.subs( sym, num )
		except:
			pass

	return expr
#
