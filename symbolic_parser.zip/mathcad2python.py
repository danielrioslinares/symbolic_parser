
import symbolic_parser
import pyperclip


s = pyperclip.paste()


print( "-"*20 )
s2 = symbolic_parser.mathcad_prime_7( s )
print(s2)
print( "-"*20 )
s3 = s2.__repr__().replace( "**", "^" ).replace( "μ_g", "u_g" ).replace( "μ_c", "u_c" )
print(s3)
print( "-"*20 )
